const express = require("express");
const router = express.Router();

const auth = require("../middleware/AuthMiddleware");
const role = require("../middleware/roleMiddleware");

const {
  createTask,
  getTasks,
  updateTask,  deleteTask
} = require("../controllers/taskController");

router.post("/", auth, role("manager"), createTask);
router.get("/", auth, getTasks);
router.put("/:id", auth, updateTask);
router.delete("/:id", auth, role("manager"), deleteTask);

module.exports = router;
