const Task = require("../models/Task");
const Activity = require("../models/ActivityLog");

exports.createTask = async (req, res) => {
  const task = await Task.create({ ...req.body, createdBy: req.user.id });
  await Activity.create({ action: "CREATE", taskId: task._id, userId: req.user.id });
  res.json(task);
};

exports.getTasks = async (req, res) => {
  const tasks = req.user.role === "manager"
    ? await Task.find()
    : await Task.find({ assignedTo: req.user.id });
  res.json(tasks);
};

exports.updateTask = async (req, res) => {
  await Task.findByIdAndUpdate(req.params.id, req.body);
  await Activity.create({ action: "UPDATE", taskId: req.params.id, userId: req.user.id });
  res.json({ message: "Updated" });
};

exports.deleteTask = async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  await Activity.create({ action: "DELETE", taskId: req.params.id, userId: req.user.id });
  res.json({ message: "Deleted" });
};
