require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const connectDB = require("./config/db");

const app = express();
connectDB();

app.use(cors());
app.use(express.json());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/tasks", require("./routes/TaskRoutes"));

app.listen(5000, () => console.log("Server running on port 5000"));
