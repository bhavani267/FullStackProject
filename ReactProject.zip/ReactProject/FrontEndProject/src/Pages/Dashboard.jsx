import { useEffect, useState, useContext } from "react";
import { AuthContext } from "../Context/AuthContext";

export default function Dashboard() {
  const { token } = useContext(AuthContext);
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/tasks", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(setTasks);
  }, []);

  return (
    <div className="p-6 dark:bg-gray-900 dark:text-white">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      {tasks.map(t => (
        <div key={t._id} className="p-3 bg-gray-200 dark:bg-gray-700 mb-2">
          {t.title} - {t.status}
        </div>
      ))}
    </div>
  );
}
