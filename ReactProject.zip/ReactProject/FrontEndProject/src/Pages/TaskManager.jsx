import React, { useContext, useState } from 'react'
import { useEffect } from 'react'
import { AuthContext } from '../Auth'

function Tasks() {
    const {token}=useContext(AuthContext)
    const[tasks,SetTasks]=useState([])
    useEffect(()=>{
        fetch("",{headers:{Autorization:`Bearer ${Token}`}})
        .then(res=>res.json())
        .then(SetTasks)
    },[])
  return (
        tasks.map(t => <div key={t._id}>{t.title}</div>)
  )
}

export default Tasks