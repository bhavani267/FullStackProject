import React, { useContext } from 'react'
import { AuthContext } from '../Auth'
function Login() {
    const {setToken}=useContext(AuthContext)
    const login=async()=>{
        const res=await fetch("",{
            method:"POST",
            headers:{"content-type":"application/json"},body:JSON.stringify(
                {email:"Example@gmail.com",password:"1234"})
        })
        const data=await res.json()
        setToken(data.Token)
    }
  return (
    <div>
     <button onClick={login}>login</button>
    </div>
  )
}

export default Login