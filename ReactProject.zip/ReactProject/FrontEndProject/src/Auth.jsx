import { createContext,useState } from "react";

export const AuthContext=createContext()
export const AuthProvider=({Children})=>{
    const [token,setToken]=useState(null)
    const[dark,setDark]=useState(false)
return(
    <AuthContext.Provider value={{token,setToken,dark,setDark}}>{Children}</AuthContext.Provider>
)
}